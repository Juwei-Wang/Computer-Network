#include "Service.h"

int Lower(int fd, const char* message, int len, struct sockaddr* client, int client_len) {
    char buf[MAX_BUFFER_SIZE];
    int idx = 0;
    char c;

    while (idx < len) {
        c = message[idx]; 
        if (c >='A' && c <= 'Z') {
            c = c + 'a' - 'A';
        }

        buf[idx] = c;
        idx++;
    }

    sendto(fd, buf, len, 0, client, client_len);    
    return 0;

}