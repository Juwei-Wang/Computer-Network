#include "Service.h"
int Identity(int fd, const char* message, int len, struct sockaddr*client, int client_len) {

    sendto(fd, message, len, 0, client, client_len);    

    return 0;
}